//-----------------------------------------------------------------------------------
//Name : HARSHAL HIWALE
//Roll No. : 21123
//Batch : F1
//-----------------------------------------------------------------------------------

#include "mainwindow.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();

    return a.exec();
}
