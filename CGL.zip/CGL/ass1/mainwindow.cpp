
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<math.h>

QImage image(300, 300, QImage::Format_RGB888);

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

int MainWindow::sign(float x){
    if(x > 0)
        return 1;
    else
        return -1;
}

int MainWindow::abs(int x){
    return (x < 0) ? -x : x;
}

int MainWindow::Integer(float x){
    return (int)x;
}

void MainWindow::DDA(int x1, int y1, int x2, int y2){
    QRgb value;
    value=qRgb(255,255,255);
    int length;
    if(abs(x2 - x1) > abs(y2 - y1))
        length = abs(x2 - x1);
    else
        length = abs(y2 - y1);

    float dx,dy,x,y;
    dx = (float)(x2 - x1)/length;
    dy = (float)(y2 - y1)/length;
    x = x1 + 0.5 * sign(dx);
    y = y1 + 0.5 * sign(dy);

    int i = 1;
    while(i <= length){
        image.setPixel(Integer(x),Integer(y),value);
        x = x + dx;
        y = y + dy;
        i++;
    }
}

void MainWindow::Bresenham(int x1, int y1, int x2, int y2){
    QRgb value;
    value=qRgb(255,255,255);
    int x,y,dx,dy,S1,S2,interchange = 0;
    float m,e;
    x = x1;
    y = y1;
    dx = abs(x2 - x1);
    dy = abs(y2 - y1);
    S1 = sign(x2 - x1);
    S2 = sign(y2 - y1);
    if(dy > dx){
        int temp = dx;
        dx = dy;
        dy = temp;
        interchange = 1;
    }
    else
        interchange = 0;
    m = (float)dy/dx;
    e = m - 0.5;
    for(int i = 1; i<= dx; i++){
        image.setPixel(x,y,value);
        while(e >= 0){
            if(interchange == 1)
                x = x + S1;
            else
                y = y + S2;
            e = e - 2 * dx;
        }
        if(interchange == 1)
            y = y + S2;
        else
            x = x + S1;
        e = e + 2 * dy;
    }
}

void MainWindow::on_pushButton_clicked()
{
    QString s1,s2,s3,s4;
    s1 = ui->lineEdit->text();
    s3 = ui->lineEdit_3->text();
    int x1,x2,y1,y2;
    x1 = s1.toInt();
    x2 = s2.toInt();
    y1 = s3.toInt();
    y2 = s4.toInt();
    DDA(x1,y1,x2,y2);
    ui->label_5->setPixmap(QPixmap::fromImage(image));
    ui->label_5->show();
}



void MainWindow::on_pushButton_3_clicked()
{
    QString s1,s2,s3,s4;
    s1 = ui->lineEdit->text();  
    s3 = ui->lineEdit_3->text();
    int x1,x2,y1,y2;
    x1 = s1.toInt();
    x2 = s2.toInt();
    y1 = s3.toInt();
    y2 = s4.toInt();
    Bresenham(x1,y1,x2,y2);
    ui->label_5->setPixmap(QPixmap::fromImage(image));
    ui->label_5->show();
}

void MainWindow::on_pushButton_4_clicked()
{
    QString s1,s2,s3,s4;
    s1 = ui->lineEdit_5->text();
    s2 = ui->lineEdit_6->text();
    s3 = ui->lineEdit->text();
    s4 = ui->lineEdit_3->text();
    int l, b, x, y;
    l = s1.toInt();
    b = s2.toInt();
    x = s3.toInt();
    y = s4.toInt();
    int x1,y1,x2,y2;
    Bresenham(x,y,x + l,y);
    Bresenham(x,y,x,y + b);
    Bresenham(x + l,y,x + l,y + b);
    Bresenham(x,y + b,x + l,y + b);
    DDA((x + l/2),y,x + l,(y + b/2));
    DDA(x + l,y + b/2 ,x + l/2 ,y + b);
    DDA((x + l/2),y,x,(y + b/2));
    DDA(x + l/2,y + b,x,y + b/2);
    Bresenham(x + l/4,y + b/4,x + 3*l/4,y + b/4);
    Bresenham(x + 3*l/4,y + b/4,x + 3*l/4,y + 3*b/4);
    Bresenham(x + 3*l/4,y + 3*b/4,x + l/4,y + 3*b/4);
    Bresenham(x + l/4,y + 3*b/4,x + l/4,y + b/4);

    ui->label_5->setPixmap(QPixmap::fromImage(image));
    ui->label_5->show();
}
