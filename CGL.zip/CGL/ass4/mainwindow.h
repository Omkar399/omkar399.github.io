#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include<QMouseEvent>
#include <QMainWindow>
#include<QColorDialog>
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT
    bool start;
    QColor C;
    int p,q,ver;
    float a[100],b[100];

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    void dda(float,float,float,float);
    void mousePressEvent(QMouseEvent *);
    int sign(float);

void mouseDoubleClickEvent(QMouseEvent * );
void seed(int ,int );
private:
    Ui::MainWindow *ui;
private slots:
    void on_pushButton_clicked();
};

#endif // MAINWINDOW_H
