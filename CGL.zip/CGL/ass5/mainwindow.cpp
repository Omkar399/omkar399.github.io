#include "mainwindow.h"
#include "ui_mainwindow.h"
QImage image(500,500,QImage::Format_RGB888);
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}
void MainWindow::mousePressEvent(QMouseEvent *ev)
{
    if(start==true)
    {
        int p,q;
        p=ev->pos().x();
        q=ev->pos().y();
        a[ver]=p;
        b[ver]=q;
        if(ev->button()==Qt::RightButton)
        {
            dda(a[0],b[0],a[ver-1],b[ver-1]);
            start=false;
        }
        else{
            if(ver>0){
                dda(a[ver-1],b[ver-1],a[ver],b[ver]);
            }
        }
        ver++;
    }
}
void MainWindow::mouseDoubleClickEvent(QMouseEvent * e)
{
    int p=e->pos().x();
    int q=e->pos().y();
    seed(p,q);
    ui->label->setPixmap(QPixmap::fromImage(image));
}
void MainWindow::seed(int x,int y)
{
    QRgb col=image.pixel(x,y);
    if(col!=C.rgb())
    {
        image.setPixel(x,y,C.rgb());
        seed(x,y+1);
        seed(x,y-1);
        seed(x+1,y);
        seed(x-1,y);
    }
}
void MainWindow::dda(float x1, float y1, float x2, float y2)
{
    float x,y,dx,dy,len;
    dx=abs(x2-x1);
    dy=abs(y2-y1);
    if(dx>=dy)
    {
        len=dx;
    }
    else
    {
        len=dy;
    }
    dx=dx/len*sign(x2-x1);
    dy=dy/len*sign(y2-y1);
    x=x1;
    y=y1;
    int i=1;
    while(i<=len)
    {
        image.setPixel(x,y,C.rgb());
        x=x+dx;
        y=y+dy;
        i++;
    }
    image.setPixel(x,y,C.rgb());

    ui->label->setPixmap(QPixmap::fromImage(image));
}
int MainWindow::sign(float t)
{
    if(t<0){
        return -1;
    }
    return 1;
}
MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::on_pushButton_clicked()
{
    C=QColorDialog::getColor();
}
