#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QMouseEvent"
#include<cmath>
#include<iostream>
QImage image(400,400, QImage::Format_RGB888);
QRgb value=qRgb(255,255,255);
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    start=true;
    dda(0, -200, 0, 200);
    dda(-200, 0, 200, 0);
    j=0;
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::mousePressEvent(QMouseEvent *ev)
{
    if(start==true)
    {
      int p=ev->pos().x();
        int q=ev->pos().y();
        a[j]=p - 200;
        b[j]=q - 200;

    if(ev->button()==Qt::RightButton)
       {
        dda(a[0],b[0],a[j-1],b[j-1]);
        start=false;
       }
      else
        {
        if(j>0)
        {
            dda(a[j-1],b[j-1],a[j],b[j]);
        }
      }
    j++;
    }
}

void MainWindow::drawAxis(){
    dda(0, -200, 0, 200);
    dda(-200, 0, 200, 0);
    ui->label->setPixmap(QPixmap::fromImage(image));
}

void MainWindow::clear(){
    for(int i = 0; i < 400; i++){
        for(int j = 0; j < 400; j++){
            image.setPixel(i,j,qRgb(0,0,0));
        }
    }
    ui->label->setPixmap(QPixmap::fromImage(image));
}


void MainWindow::dda(float X1,float Y1,float X2,float Y2)
{
   X1 += 200;
   X2 += 200;
   Y2 += 200;
   Y1 += 200;
   float dx=abs(X2-X1);
   float dy=abs(Y2-Y1);
   float step;
   if(dx>dy)
       step=dx;
   else
       step=dy;
   dx=dx/step;
   dy=dy/step;
   float x=X1;
   float y=Y1;
   float i=1;
   while(i<=step)
   {
     image.setPixel(x,y,value);
     x=x+dx*sign(X2-X1);
     y=y+dy*sign(Y2-Y1);
     i++;
   }

   ui->label->setPixmap(QPixmap::fromImage(image));
}
int MainWindow::sign(float p)
{
    if(p<0)
    {return -1;}
    else
    {
        return 1;
    }
}

void MainWindow::matMultiplication(float a[][3], float b[][3], float c[][3]){
    for(int x = 0; x < j; x++){
        for(int y = 0; y < 3; y++){
            c[x][y] = 0;
            for(int z = 0; z < 3; z++){
                c[x][y] += a[x][z] * b[z][y];
            }
        }
    }
}

//Scalling
void MainWindow::on_pushButton_clicked()
{
    float sx = ui->lineEdit->text().toFloat();
    float sy = ui->lineEdit_2->text().toFloat();
    sx = (sx == 0) ? 0 : sx;
    sy = (sy == 0) ? 0 : sy;
    float Mt[3][3] = {0};
    Mt[0][0] = sx;
    Mt[1][1] = sy;
    Mt[2][2] = 1;

    float mat[j][3];
    for(int i = 0; i < j; i++){
        mat[i][2] = 1;
        mat[i][0] = a[i];
        mat[i][1] = b[i];
    }

    float result[j][3];
    matMultiplication(mat,Mt,result);

    for(int i = 0; i < j; i++){
        a[i] = result[i][0];
        b[i] = result[i][1];
    }

    //clearing the screen
    clear();
    drawAxis();

    for(int i = 1; i < j; i++){
           dda(a[i-1],b[i-1],a[i],b[i]);
    }
    dda(a[0],b[0],a[j - 1],b[j - 1]);
}

//Translation
void MainWindow::on_pushButton_2_clicked()
{
    float x = ui->lineEdit_3->text().toInt();
    float y = ui->lineEdit_4->text().toInt();
    float Mt[3][3] = {0};
    Mt[0][0] = 1;
    Mt[1][1] = 1;
    Mt[2][0] = x;
    Mt[2][1] = y;
    Mt[2][2] = 1;

    float mat[j][3];
    for(int i = 0; i < j; i++){
        mat[i][2] = 1;
        mat[i][0] = a[i];
        mat[i][1] = b[i];
    }

    float result[j][3];
    matMultiplication(mat,Mt,result);

    for(int i = 0; i < j; i++){
        a[i] = result[i][0];
        b[i] = result[i][1];
    }

    //clearing the screen
    clear();
    drawAxis();

    for(int i = 1; i < j; i++){
           dda(a[i-1],b[i-1],a[i],b[i]);
    }
    dda(a[0],b[0],a[j - 1],b[j - 1]);
}

//Rotation
void MainWindow::on_pushButton_3_clicked()
{
    float angle = ui->lineEdit_5->text().toFloat();
    angle = 3.14 / 180 * angle;
    float Mt[3][3] = {0};
    Mt[0][0] = cos(angle);
    Mt[0][1] = -sin(angle);
    Mt[1][0] = sin(angle);
    Mt[1][1] = cos(angle);
    Mt[2][2] = 1;

    float mat[j][3];
    for(int i = 0; i < j; i++){
        mat[i][2] = 1;
        mat[i][0] = a[i];
        mat[i][1] = b[i];
    }

    float result[j][3];
    matMultiplication(mat,Mt,result);

    for(int i = 0; i < j; i++){
        a[i] = result[i][0];
        b[i] = result[i][1];
    }

    //clearing the screen
    clear();
    drawAxis();

    for(int i = 1; i < j; i++){
           dda(a[i-1],b[i-1],a[i],b[i]);
    }
    dda(a[0],b[0],a[j - 1],b[j - 1]);
}

void MainWindow::on_pushButton_4_clicked()
{
    float x = ui->lineEdit_6->text().toInt();
    float y = ui->lineEdit_7->text().toInt();
    float Mt[3][3] = {0};
    Mt[0][0] = 1;
    Mt[1][1] = 1;
    Mt[2][0] = x;
    Mt[2][1] = y;
    Mt[2][2] = 1;

    float mat[j][3];
    for(int i = 0; i < j; i++){
        mat[i][2] = 1;
        mat[i][0] = a[i];
        mat[i][1] = b[i];
    }

    float result[j][3];
    matMultiplication(mat,Mt,result);

    for(int i = 0; i < j; i++){
        a[i] = result[i][0];
        b[i] = result[i][1];
    }

    float Mt2[3][3] = {0};
    float angle = ui->lineEdit_8->text().toFloat();
    angle = 3.14 / 180 * angle;
    Mt2[0][0] = cos(angle);
    Mt2[0][1] = -sin(angle);
    Mt2[1][0] = sin(angle);
    Mt2[1][1] = cos(angle);
    Mt2[2][2] = 1;

    for(int i = 0; i < j; i++){
        mat[i][2] = 1;
        mat[i][0] = a[i];
        mat[i][1] = b[i];
    }

    matMultiplication(mat,Mt2,result);

    for(int i = 0; i < j; i++){
        a[i] = result[i][0];
        b[i] = result[i][1];
    }

    for(int i = 0; i < 3; i++){
        Mt[i][0] = 0;
        Mt[i][1] = 0;
        Mt[i][2] = 0;
    }
    x = ui->lineEdit_6->text().toInt();
    y = ui->lineEdit_7->text().toInt();
    Mt[0][0] = 1;
    Mt[1][1] = 1;
    Mt[2][0] = x;
    Mt[2][1] = y;
    Mt[2][2] = 1;

    for(int i = 0; i < j; i++){
        mat[i][2] = 1;
        mat[i][0] = a[i];
        mat[i][1] = b[i];
    }

    matMultiplication(mat,Mt,result);

    for(int i = 0; i < j; i++){
        a[i] = result[i][0];
        b[i] = result[i][1];
    }

    //Clearing the screen
    clear();
    drawAxis();

    for(int i = 1; i < j; i++){
           dda(a[i-1],b[i-1],a[i],b[i]);
    }
    dda(a[0],b[0],a[j - 1],b[j - 1]);
}
