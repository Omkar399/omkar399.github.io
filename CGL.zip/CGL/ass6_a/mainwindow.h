#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    void dda(float,float,float,float);
    int sign(float);
    void mousePressEvent(QMouseEvent *ev);
    void matMultiplication(float a[][3], float b[][3], float c[][3]);
    void clear();
    void drawAxis();
    bool start;
    int j;
    int a[20];
    int b[20];
    ~MainWindow();


private slots:



    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
