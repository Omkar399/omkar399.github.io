#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QMouseEvent"

static int LEFT=1,RIGHT=2,BOTTOM=4,TOP=8,xl=-100,yl=-50,xh=100,yh=50;

QImage image(400,400,QImage::Format_RGB888);
QRgb value = qRgb(255,255,255);

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    n=0;
    flag = 0;
    ui->setupUi(this);
    dda(-100,50,100,50);
    dda(-100,-50,100,-50);
    dda(100,50,100,-50);
    dda(-100,50,-100,-50);
}

MainWindow::~MainWindow()
{
    delete ui;
}

int MainWindow::sign(float p)
{
    if(p<0)
    {return -1;}
    else
    {
        return 1;
    }
}

void MainWindow::mousePressEvent(QMouseEvent *ev)
{
    if(flag == 0){
        x1[n] = (float)ev->pos().x();
        y1[n] = (float)ev->pos().y();
        flag++;
        x1[n] -= 200;
        y1[n] -= 200;
    }else if(flag == 1){
        x2[n] = (float)ev->pos().x();
        y2[n] = (float)ev->pos().y();
        flag = 0;
        x2[n] -= 200;
        y2[n] -= 200;
        dda(x1[n],y1[n],x2[n],y2[n]);
        n++;
    }
}

void MainWindow::dda(float X1, float Y1, float X2, float Y2){
    X1 += 200;
    X2 += 200;
    Y2 += 200;
    Y1 += 200;
    float dx=abs(X2-X1);
    float dy=abs(Y2-Y1);
    float step;
    if(dx>dy)
        step=dx;
    else
        step=dy;
    dx=dx/step;
    dy=dy/step;
    float x=X1;
    float y=Y1;
    float i=1;
    while(i<=step)
    {
        image.setPixel(x,y,value);
        x=x+dx*sign(X2-X1);
        y=y+dy*sign(Y2-Y1);
        i++;
    }

    ui->label->setPixmap(QPixmap::fromImage(image));
}

//On Clip Button click
void MainWindow::on_pushButton_clicked()
{
    for(int i=0;i<n;i++){
        value = qRgb(0,0,0);
        dda(x1[i],y1[i],x2[i],y2[i]);
        clip(x1[i],y1[i],x2[i],y2[i]);
        ui->label->show();
    }
}

int MainWindow::getCode(int x,int y){
    int code = 0;

    if(y > yh) code |=TOP;
    if(y < yl) code |=BOTTOM;
    if(x < xl) code |=LEFT;
    if(x > xh) code |=RIGHT;
    return code;
}

void MainWindow::clip(int x1,int y1,int x2,int y2)
{
    int outcode1 = getCode(x1,y1);
    int outcode2 = getCode(x2,y2);

    int accept = 0;
    while(1)
    {
        float m =(float)(y2-y1)/(x2-x1);

        if(outcode1==0 && outcode2==0){
            accept = 1;
            break;
        }
        else if((outcode1 & outcode2)!=0){
            break;
        }else{
            int x,y;
            int temp;
            if(outcode1==0)
                temp = outcode2;
            else
                temp = outcode1;

            if(temp & TOP){
                x = x1+ (yh-y1)/m;
                y = yh;
            }
            else if(temp & BOTTOM){
                x = x1+ (yl-y1)/m;
                y = yl;
            }else if(temp & LEFT){
                x = xl;
                y = y1+ m*(xl-x1);
            }else if(temp & RIGHT){
                x = xh;
                y = y1+ m*(xh-x1);
            }

            if(temp == outcode1){
                x1 = x;
                y1 = y;
                outcode1 = getCode(x1,y1);
            }else{
                x2 = x;
                y2 = y;
                outcode2 = getCode(x2,y2);
            }
        }
    }
    if(accept)
    {
        value=qRgb(255,255,255);
        dda(x1,y1,x2,y2);
    }
}
