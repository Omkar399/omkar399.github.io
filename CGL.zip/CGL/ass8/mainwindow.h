#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    int n;
    explicit MainWindow(QWidget *parent = 0);
    void mousePressEvent(QMouseEvent *ev);
    void dda(float a, float b, float c, float d);
    int sign(float);
    void clip(int x1,int y1,int x2,int y2);
    int getCode(int x,int y);
    int flag;
    float x1[10],x2[10],y1[10],y2[10];
    ~MainWindow();

private slots:
    void on_pushButton_clicked();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
