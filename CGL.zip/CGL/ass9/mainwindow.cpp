#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QMouseEvent"
#include <cmath>
#include <iostream>

QImage img(400,400,QImage::Format_RGB888);

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    start = true;
    ver = 0;
    ui->setupUi(this);
    dda(-199,0,199,0);
    dda(0,199,0,-199);
}

MainWindow::~MainWindow()
{
    delete ui;
}

//Function to clear image
void MainWindow::clear(){
    for(int i = 0; i < 400; i++){
        for(int j = 0; j < 400; j++){
            img.setPixel(static_cast<int>(i),static_cast<int>(j),qRgb(0,0,0));
        }
    }
    ui->label->setPixmap(QPixmap::fromImage(img));
}

//Matix Multiplication
float** MainWindow::multiplyMatrix(float a[][3], float b[3][3]){
    float** result;
    result = new float*[ver];
    for(int i = 0; i < ver; i++){
        result[i] = new float[3];
    }
    for(int i = 0; i < ver; i++){
        for(int j = 0; j < 3; j++){
            result[i][j] = 0;
            for(int k = 0; k < 3; k++){
                result[i][j] += a[i][k] * b[k][j];
            }
        }
    }
    return result;
}

//Matix Multiplication
float** MainWindow::multiplyMatrix(float **a, float b[3][3]){
    float** result;
    result = new float*[ver];
    for(int i = 0; i < ver; i++){
        result[i] = new float[3];
    }
    for(int i = 0; i < ver; i++){
        for(int j = 0; j < 3; j++){
            result[i][j] = 0;
            for(int k = 0; k < 3; k++){
                result[i][j] += a[i][k] * b[k][j];
            }
        }
    }
    return result;
}

//Line Drawing algorithm
void MainWindow::dda(float x1,float y1,float x2,float y2)
{
    x1 += 200;
    x2 += 200;
    y1 += 200;
    y2 += 200;
    float x,y,dx,dy,l,i=1;
    QRgb value;
    value=qRgb(255,255,255);

    l=std::abs(x2-x1)>std::abs(y2-y1)?std::abs(x2-x1):std::abs(y2-y1);
    dx=(x2-x1)/l;
    dy=(y2-y1)/l;

    x=x1+0.5f;
    y=y1+0.5f;
    do
    {
        img.setPixel(static_cast<int>(x),static_cast<int>(y),value);
        x = x + dx;
        y = y + dy;
        i++;
    }while(i <= l);

    ui->label->setPixmap(QPixmap::fromImage(img));

}

//Mouse Interface
void MainWindow::mousePressEvent(QMouseEvent *ev)
{
    if(start==true)
    {
        float p=ev->pos().x();
        float q=ev->pos().y();
        a[ver]=p - 200;
        b[ver]=q - 200;
        if(ev->button()==Qt::RightButton)
        {
            dda(a[0],b[0],a[ver],b[ver]);
            start=false;
        }
        else {
            if(ver>0)
            {
                dda(a[ver],b[ver],a[ver-1],b[ver-1]);
            }
        }
        ver++;
    }
}

//Reflection about X axis
void MainWindow::on_pushButton_clicked()
{
    float objMat[ver][3];
    for(int i = 0; i < ver; i++){
        objMat[i][0] = a[i];
        objMat[i][1] = b[i];
        objMat[i][2] = 1;
    }

    float transMat[3][3] = {0};
    transMat[0][0] = 1;
    transMat[1][1] = -1;
    transMat[2][2] = 1;

    float **result;
    result = multiplyMatrix(objMat,transMat);

    for(int i = 0; i < ver; i++){
        a[i] = result[i][0];
        b[i] = result[i][1];
    }

    clear();
    showObject();
}

//Function to show object
void MainWindow::showObject(){

    dda(-199,0,199,0);
    dda(0,199,0,-199);

    for(int i = 0; i < ver - 1; i++){
        dda(a[i],b[i],a[i + 1], b[i + 1]);
    }
    dda(a[0],b[0],a[ver - 1],b[ver - 1]);
}

//Reflection about Y axis
void MainWindow::on_pushButton_2_clicked()
{
    float objMat[ver][3];
    for(int i = 0; i < ver; i++){
        objMat[i][0] = a[i];
        objMat[i][1] = b[i];
        objMat[i][2] = 1;
    }

    float transMat[3][3] = {0};
    transMat[0][0] = -1;
    transMat[1][1] = 1;
    transMat[2][2] = 1;

    float **result;
    result = multiplyMatrix(objMat,transMat);

    for(int i = 0; i < ver; i++){
        a[i] = result[i][0];
        b[i] = result[i][1];
    }

    clear();
    showObject();
}

//Reflection about X = Y axis
void MainWindow::on_pushButton_3_clicked()
{
    float objMat[ver][3];
    for(int i = 0; i < ver; i++){
        objMat[i][0] = a[i];
        objMat[i][1] = b[i];
        objMat[i][2] = 1;
    }

    float transMat[3][3] = {0};
    transMat[0][1] = 1;
    transMat[1][0] = 1;
    transMat[2][2] = 1;

    float **result;
    result = multiplyMatrix(objMat,transMat);

    for(int i = 0; i < ver; i++){
        a[i] = -result[i][0];
        b[i] = -result[i][1];
    }

    clear();
    showObject();
}

//Rotation about arbitrary point
void MainWindow::on_pushButton_4_clicked()
{
    float x = ui->lineEdit->text().toFloat();
    float y = ui->lineEdit_2->text().toFloat();
    float angle = ui->lineEdit_3->text().toFloat();
    angle = angle * float(M_PI) / 180;

    float objMat[ver][3];
    for(int i = 0; i < ver; i++){
        objMat[i][0] = a[i];
        objMat[i][1] = b[i];
        objMat[i][2] = 1;
    }

    float transMat[3][3] = {0};
    transMat[0][0] = 1;
    transMat[1][1] = 1;
    transMat[2][2] = 1;
    transMat[2][0] = -x;
    transMat[2][1] = -y;

    float **result = multiplyMatrix(objMat,transMat);

    float transMat2[3][3] = {0};
    transMat2[2][2] = 1;
    transMat2[0][0] = cos(angle);
    transMat2[0][1] = sin(angle);
    transMat2[1][0] = -sin(angle);
    transMat2[1][1] = cos(angle);
    result = multiplyMatrix(result, transMat2);

    transMat[2][0] = x;
    transMat[2][1] = y;

    result = multiplyMatrix(result, transMat);

    for(int i = 0; i < ver; i++){
        a[i] = result[i][0];
        b[i] = result[i][1];
    }

    clear();
    showObject();
}
