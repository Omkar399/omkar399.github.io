#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    float** multiplyMatrix(float a[20][3], float b[3][3]);
    float** multiplyMatrix(float **a, float b[3][3]);
    void dda(float x1,float y1,float x2,float y2);
    void mousePressEvent(QMouseEvent *ev);
    void showObject();
    void clear();
    bool start;
    int ver;
    float a[20];
    float b[20];
    ~MainWindow();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
