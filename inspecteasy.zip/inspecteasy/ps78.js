//A js file i9 suppose
//here is the 2nd part =>  F{L34rN_70